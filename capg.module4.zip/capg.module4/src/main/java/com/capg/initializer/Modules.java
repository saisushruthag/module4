package com.capg.initializer;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Modules {
	
	public static WebDriver driver;
	static String browser;
	public static void setBrowser() {
		PropertiesDetails.readProperties();
		browser=PropertiesDetails.prop.getProperty("browser");
	}
	public static void setBrowserConfig() {
		if(browser.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\sushru\\Desktop\\eclipse\\capg.module4\\src\\main\\java\\chromedriver.exe");
		}
	}
	public static void runTest() {
		driver=new ChromeDriver();
		driver.get(PropertiesDetails.prop.getProperty("url"));		
	}
	public static void endTest() {
		driver.quit();
	}

}
