package com.capg.initializer;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesDetails {
	
	static Properties prop = new Properties();
	public static void readProperties() {
		
		try {
			InputStream inputstream = new FileInputStream("C:\\Users\\sushru\\Desktop\\eclipse\\capg.module4\\src\\main\\java\\config.properties");
			prop.load(inputstream);
			System.out.println(prop.getProperty("browser"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
