package com.capg.testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\Users\\sushru\\Desktop\\eclipse\\capg.module4\\src\\main\\java\\com\\capg\\feature\\payment.feature", 
					glue = {"com.capg.stepDefinition"})
public class TestRunner {

}
